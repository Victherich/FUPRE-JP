<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

$id = $_POST['id'] ?? '';
if (empty($id)) {
    echo json_encode(["success" => false, "message" => "Registration ID missing"]);
    exit;
}

// Fetch registration + user info
$stmt = $conn->prepare("SELECT name, email, conference_id FROM conference_registrations WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$res) {
    echo json_encode(["success" => false, "message" => "Registration not found"]);
    exit;
}

$name = $res['name'];
$email = $res['email'];
$conference_id = $res['conference_id'];

// Fetch conference title
$stmtConf = $conn->prepare("SELECT title FROM conferences WHERE id = ?");
$stmtConf->bind_param("i", $conference_id);
$stmtConf->execute();
$stmtConf->bind_result($confTitle);
$stmtConf->fetch();
$stmtConf->close();

// Generate 6-digit random passcode
$passcode = rand(100000, 999999);

// Update passcode in DB
$stmtUpd = $conn->prepare("UPDATE conference_registrations SET passcode = ?, registration_status = 'Approved' WHERE id = ?");
$stmtUpd->bind_param("si", $passcode, $id);
if ($stmtUpd->execute()) {

    // Send approval email
    $headers  = "From: cosjournals@fupre.edu.ng\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $subject = "Conference Registration Approved";
    $message = "Dear $name,\n\nYour registration for \"$confTitle\" has been approved.\n".
               "Your passcode to access the conference is: $passcode\n\n".
               "Keep this code safe.\n\nFUPRE JP Conference Team";

    mail($email, $subject, $message, $headers);

    echo json_encode(["success" => true, "message" => "Registration approved and passcode sent"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update registration"]);
}

$stmtUpd->close();
$conn->close();
?>
