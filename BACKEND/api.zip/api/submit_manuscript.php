<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

include 'config.php'; // Database connection

$response = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form fields
    $submissionType = $_POST['submissionType'] ?? '';
    $originalArticleCode = $_POST['originalArticleCode'] ?? '';
    $title = $_POST['title'] ?? '';
    $abstract = $_POST['abstract'] ?? '';
    $keywords = $_POST['keywords'] ?? '';
    $coAuthors = $_POST['coAuthors'] ?? '';
    $articleCategory = $_POST['articleCategory'] ?? '';
    $articleCode = $_POST['articleCode'] ?? '';
    $authorId = $_POST['author_id'] ?? '';
    $file = $_FILES['manuscriptFile'] ?? null;

    // Validate required fields
    if (empty($submissionType) || empty($title) || empty($abstract) || empty($keywords) || empty($articleCategory) || empty($articleCode) || empty($file) || empty($authorId)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    // Handle Revised Submission
    if ($submissionType === "Revised Submission" && empty($originalArticleCode)) {
        echo json_encode(['success' => false, 'message' => 'Original Article Code is required for Revised Submissions.']);
        exit;
    }

    // File upload settings
    $uploadDir = "uploads/submitted_manuscripts/";
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create directory if not exists
    }

    $fileName = basename($file['name']);
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowedExtensions = ['pdf', 'doc', 'docx'];
    
    if (!in_array($fileExt, $allowedExtensions)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file type. Only PDF, DOC, and DOCX allowed.']);
        exit;
    }

    $newFileName = time() . "_" . rand(1000, 9999) . "." . $fileExt; // Unique file name
    $filePath = $uploadDir . $newFileName;

    if (move_uploaded_file($file["tmp_name"], $filePath)) {

        // Handle New Submission
        if ($submissionType === "New Submission") {
            $query = "INSERT INTO manuscripts (author_id, title, abstract, keywords, co_authors, article_category, article_code, file_path, submission_type) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("issssssss", $authorId, $title, $abstract, $keywords, $coAuthors, $articleCategory, $articleCode, $filePath, $submissionType);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'New Manuscript submitted successfully!', 'file_url' => $filePath]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to save new manuscript details in the database.']);
            }
        } 
        // Handle Revised Submission
        else if ($submissionType === "Revised Submission") {
            $query = "INSERT INTO manuscripts (author_id, title, abstract, keywords, co_authors, article_category, article_code, original_article_code, file_path, submission_type) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("isssssssss", $authorId, $title, $abstract, $keywords, $coAuthors, $articleCategory, $articleCode, $originalArticleCode, $filePath, $submissionType);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Revised Manuscript submitted successfully!', 'file_url' => $filePath]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to save revised manuscript details in the database.']);
            }
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to upload file.']);
    }

    $conn->close();
}
?>
