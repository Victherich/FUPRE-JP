<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

if (isset($_GET['author_id'])) {
    $author_id = $_GET['author_id'];

    if (!filter_var($author_id, FILTER_VALIDATE_INT)) {
        echo json_encode(['success' => false, 'error' => 'Invalid Author ID']);
        exit;
    }

    // Fetch manuscripts for the given author
    $query = "SELECT * 
              FROM manuscripts 
              WHERE author_id = ? 
              ORDER BY created_at DESC";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $author_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $manuscripts = [];

    while ($row = $result->fetch_assoc()) {
        $manuscripts[] = [
            'id' => $row['id'],
            'title' => $row['title'],
            'article_code' => $row['article_code'],
            'article_category' => $row['article_category'],
            'file_path' => $row['file_path'],
            'submittedDate' => $row['created_at'],
            'status' => $row['status'],
            'lastUpdated' => $row['updated_at'],
            'abstract' => $row['abstract'],
            'APC' => $row['APC'],
            'submission_type' => $row['submission_type'],
            'original_article_code' => $row['original_article_code'],
        ];
    }

    echo json_encode(['success' => true, 'manuscripts' => $manuscripts]);

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Author ID is required']);
}

mysqli_close($conn);
?>
