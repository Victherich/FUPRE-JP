<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}

$id = $_POST['id'] ?? '';

if (empty($id)) {
    echo json_encode(["success" => false, "message" => "Conference ID is required."]);
    exit;
}

/* -------------------------------------------------------
    1. CHECK IF ANYONE HAS REGISTERED FOR THIS CONFERENCE
-------------------------------------------------------- */

$check = $conn->prepare("SELECT COUNT(*) AS total FROM conference_registrations WHERE conference_id = ?");
$check->bind_param("i", $id);
$check->execute();
$result = $check->get_result()->fetch_assoc();

if ($result['total'] > 0) {
    echo json_encode([
        "success" => false,
        "message" => "This conference cannot be deleted because participants have already registered."
    ]);
    exit;
}

/* -------------------------------------------------------
    2. FETCH THE FLIER PATH BEFORE DELETING
-------------------------------------------------------- */

$getQuery = $conn->prepare("SELECT flier_path FROM conferences WHERE id = ?");
$getQuery->bind_param("i", $id);
$getQuery->execute();
$res = $getQuery->get_result();
$conf = $res->fetch_assoc();

if (!$conf) {
    echo json_encode(["success" => false, "message" => "Conference not found."]);
    exit;
}

$flierPath = $conf['flier_path'];

/* -------------------------------------------------------
    3. DELETE THE CONFERENCE
-------------------------------------------------------- */

$delQuery = $conn->prepare("DELETE FROM conferences WHERE id = ?");
$delQuery->bind_param("i", $id);

if ($delQuery->execute()) {

    // Delete flier file
    if (!empty($flierPath) && file_exists($flierPath)) {
        unlink($flierPath);
    }

    echo json_encode([
        "success" => true,
        "message" => "Conference deleted successfully."
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to delete conference."
    ]);
}

$conn->close();
?>
