
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON payload.']);
    exit();
}

// Sanitize & Validate input
$fullName = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$phoneCode = trim($data['phoneCode'] ?? '');
$phone = trim($data['phone'] ?? '');
$affiliation = trim($data['affiliation'] ?? '');
$orcid = trim($data['orcid'] ?? '');
$password = $data['password'] ?? '';
$confirmPassword = $data['confirmPassword'] ?? '';

if (empty($fullName) || empty($email) || empty($phone) || empty($affiliation) || empty($password) || empty($confirmPassword)) {
    echo json_encode(['success' => false, 'error' => 'All required fields must be filled.']);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Invalid email format.']);
    exit();
}

if ($password !== $confirmPassword) {
    echo json_encode(['success' => false, 'error' => 'Passwords do not match.']);
    exit();
}

// Hash password securely
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
$verificationToken = bin2hex(random_bytes(16));

// Check if the email already exists
$stmt = $conn->prepare("SELECT id FROM editors WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'error' => 'Email is already registered.']);
    $stmt->close();
    mysqli_close($conn);
    exit();
}
$stmt->close();

// Insert user into database
$stmt = $conn->prepare("INSERT INTO editors (full_name, email, phone_code, phone_number, affiliation, orcid, password, verification_token) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $fullName, $email, $phoneCode, $phone, $affiliation, $orcid, $hashedPassword, $verificationToken);

if ($stmt->execute()) {
    // Email Verification
    $verifyUrl = "https://www.fuprecosjournals.org/editorverifyemail/$verificationToken";
    $subject = "Verify Your Editor Account";
    $message = "Hi $fullName,\n\nPlease click the link below to verify your Editor account:\n$verifyUrl\n\nBest regards,\nFUPRE JP";
    $headers = "From: no-reply@fuprecosjournals.org\r\n";

    if (mail($email, $subject, $message, $headers)) {
        echo json_encode(['success' => true, 'message' => 'Account created successfully. Please check your email inbox or spam folder to verify your account.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error sending verification email.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Error creating account.']);
}

$stmt->close();
mysqli_close($conn);
?>