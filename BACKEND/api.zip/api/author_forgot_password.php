<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON input
    $data = json_decode(file_get_contents('php://input'), true);
    $email = $data['email'] ?? '';

    // Validate email
    if (empty($email)) {
        echo json_encode(['success' => false, 'error' => 'Email is required.']);
        exit();
    }

    // Check if email exists in the authors table
    $stmt = $conn->prepare("SELECT id, full_name FROM authors WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $resetToken = bin2hex(random_bytes(16)); // Generate a unique token

        // Store reset token in the database
        $updateStmt = $conn->prepare("UPDATE authors SET reset_token = ? WHERE email = ?");
        $updateStmt->bind_param("ss", $resetToken, $email);

        if ($updateStmt->execute()) {
            // Create reset password URL
            $resetUrl = "https://www.fuprecosjournals.org/author-reset-password/$resetToken";

            // Email details
            $subject = "Password Reset Request";
            $message = "Hello " . $user['full_name'] . ",\n\n";
            $message .= "You have requested to reset your password. Please click the link below to reset it:\n";
            $message .= "$resetUrl\n\n";
            $message .= "If you did not request this, please ignore this email.\n\n";
            $message .= "Best regards,\nFUPRE JP";

            $headers = "From: no-reply@fuprecosjournals.org\r\n";

            // Send email
            if (mail($email, $subject, $message, $headers)) {
                echo json_encode(['success' => true, 'message' => 'Password reset email sent.']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Error sending password reset email.']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to generate reset token.']);
        }
        $updateStmt->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'Email not found.']);
    }

    $stmt->close();
    mysqli_close($conn);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>
