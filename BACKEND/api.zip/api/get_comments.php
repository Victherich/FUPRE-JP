<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Prevent caching
header('Cache-Control: no-cache, no-store, must-revalidate'); // HTTP 1.1
header('Pragma: no-cache'); // HTTP 1.0
header('Expires: 0'); // Proxies

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'config.php';

$manuscript_id = isset($_GET['manuscript_id']) ? intval($_GET['manuscript_id']) : 0;

if ($manuscript_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid manuscript ID']);
    exit();
}

// Get all main comments for the manuscript
$sql = "SELECT * FROM comments WHERE manuscript_id = ? AND parent_id IS NULL ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $manuscript_id);
$stmt->execute();
$result = $stmt->get_result();
$comments = [];

while ($row = $result->fetch_assoc()) {
    $comment_id = $row['id'];

    // Get all replies for each comment
    $reply_sql = "SELECT * FROM comments WHERE parent_id = ? ORDER BY created_at ASC";
    $reply_stmt = $conn->prepare($reply_sql);
    $reply_stmt->bind_param("i", $comment_id);
    $reply_stmt->execute();
    $reply_result = $reply_stmt->get_result();
    $replies = [];

    while ($reply_row = $reply_result->fetch_assoc()) {
        $replies[] = $reply_row;
    }

    $row['replies'] = $replies;
    $comments[] = $row;
}

echo json_encode(['success' => true, 'comments' => $comments]);
?>
