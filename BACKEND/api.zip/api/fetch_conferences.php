<?php
// ----------------- HEADERS -----------------
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

// ----------------- DATABASE -----------------
include 'config.php'; // Database connection

// ----------------- FETCH CONFERENCES -----------------
$query = "SELECT * FROM conferences ORDER BY created_at DESC";
$result = $conn->query($query);

if ($result) {
    $conferences = $result->fetch_all(MYSQLI_ASSOC);

    // Add flier_url key for frontend
    foreach ($conferences as &$conf) {
        $conf['flier_url'] = $conf['flier_path']; // full path or URL
    }

    echo json_encode(['success' => true, 'data' => $conferences]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch conferences.']);
}

$conn->close();
?>
