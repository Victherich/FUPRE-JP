<?php
include 'config.php';

$sql = "SELECT id FROM publications ORDER BY id DESC";
$result = $conn->query($sql);

$xml = '<?xml version="1.0" encoding="UTF-8"?>';
$xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

while ($row = $result->fetch_assoc()) {
    $xml .= '
      <url>
        <loc>https://www.fuprecosjournals.org/api/publicationdetail.php?id=' . $row["id"] . '</loc>
      </url>
    ';
}

$xml .= '</urlset>';

file_put_contents("sitemap.xml", $xml);

echo "Sitemap updated";
