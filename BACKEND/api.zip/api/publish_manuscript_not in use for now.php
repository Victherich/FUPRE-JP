<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'config.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    // Check if manuscript_id is provided
    if (!isset($input['manuscript_id'])) {
        echo json_encode(['success' => false, 'error' => 'Manuscript ID is required']);
        exit();
    }

    $manuscript_id = intval($input['manuscript_id']);

    // Update the publish column to 'published'
    $sql = "UPDATE manuscripts SET publish = 'published' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $manuscript_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Manuscript published successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to publish manuscript']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}

mysqli_close($conn);
?>
