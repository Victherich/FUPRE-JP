<?php
// Allow requests from React frontend
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'config.php'; // Include database connection

// Get the article_category from the query parameter without forcing to integer
$articleCategory = isset($_GET['article_category']) ? $_GET['article_category'] : '0';

// Prepare SQL query
if ($articleCategory === '0') {
    // Get all publications if category is 0
    $query = "SELECT * FROM publications ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
} else {
    // Get publications for the specific category
    $query = "SELECT * FROM publications WHERE article_category = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $articleCategory); // Changed to "s" for string
}

$stmt->execute();
$result = $stmt->get_result();

$publications = [];

while ($row = $result->fetch_assoc()) {
    $publications[] = [
        'id' => $row['id'],
        'author_id' => $row['author_id'],
        'title' => $row['title'],
        'abstract' => $row['abstract'],
        'keywords' => $row['keywords'],
        'co_authors' => $row['co_authors'],
        'article_category' => $row['article_category'],
        'article_code' => $row['article_code'],
        'last_revised_article_code' => $row['last_revised_article_code'],
        'file_path' => $row['file_path'],
        'doiLink' => $row['doiLink'],
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at']
    ];
}

// Return JSON response
echo json_encode(['success' => true, 'publications' => $publications]);

$stmt->close();
mysqli_close($conn);
?>
