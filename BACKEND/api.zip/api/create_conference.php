<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

include 'config.php';

$response = [];

if($_SERVER["REQUEST_METHOD"] === "POST") {

    $title = $_POST['title'] ?? '';
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $venue = $_POST['venue'] ?? '';
    $flier = $_FILES['flier'] ?? null;

    if(empty($title) || empty($start_date) || empty($venue) || !$flier){
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    // File upload
    $uploadDir = "uploads/conferences/";
    if(!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

    $flierName = time() . "_flier_" . rand(1000,9999) . "." . pathinfo($flier['name'], PATHINFO_EXTENSION);
    $flierPath = $uploadDir . $flierName;

    if(!move_uploaded_file($flier['tmp_name'], $flierPath)){
        echo json_encode(['success' => false, 'message' => 'Failed to upload flier.']);
        exit;
    }

    $query = "INSERT INTO conferences (title, start_date, end_date, venue, flier_path, created_at) 
              VALUES (?, ?, ?, ?, ?, NOW())";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $title, $start_date, $end_date, $venue, $flierPath);

    if($stmt->execute()){
        echo json_encode(['success' => true, 'message' => 'Conference created successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save conference in the database.']);
    }

    $stmt->close();
    $conn->close();
}
?>
