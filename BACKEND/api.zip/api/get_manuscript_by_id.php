<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

// Check if the manuscript ID is provided
if (isset($_GET['id'])) {
    $manuscript_id = $_GET['id'];

    // Validate the ID to be an integer
    if (!filter_var($manuscript_id, FILTER_VALIDATE_INT)) {
        echo json_encode(['success' => false, 'error' => 'Invalid Manuscript ID']);
        exit;
    }

    // Fetch manuscript by ID
    $query = "SELECT * 
              FROM manuscripts 
              WHERE id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $manuscript_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the manuscript is found
    if ($result->num_rows > 0) {
        $manuscript = $result->fetch_assoc();
        echo json_encode(['success' => true, 'manuscript' => $manuscript]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Manuscript not found']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Manuscript ID is required']);
}

mysqli_close($conn);
?>
