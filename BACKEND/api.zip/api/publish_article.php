<?php
// Allow CORS and set response type
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Include database connection
include 'config.php';

$response = [];

// Check for POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Collect form fields exactly as provided from the frontend
    $lastRevisedArticleCode = $_POST['lastRevisedArticleCode'] ?? '';
    $title = $_POST['title'] ?? '';
    $abstract = $_POST['abstract'] ?? '';
    $keywords = $_POST['keywords'] ?? '';
    $coAuthors = $_POST['coAuthors'] ?? '';
    $articleCategory = $_POST['articleCategory'] ?? '';
    $articleCode = $_POST['articleCode'] ?? '';
    $authorId = $_POST['author_id'] ?? '';
    $editorId = $_POST['editor_id'] ?? ''; // Added editor_id
    $doiLink = $_POST['doiLink'] ?? ''; // Collecting optional DOI link
    $file = $_FILES['manuscriptFile'] ?? null;

    // Validate required fields
    if (empty($title) || empty($abstract) || empty($keywords) || empty($articleCategory) || empty($articleCode) || empty($file) || empty($authorId) || empty($editorId)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    // File upload settings
    $uploadDir = "uploads/published_articles/";
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create directory if not exists
    }

    $fileName = basename($file['name']);
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowedExtensions = ['pdf', 'doc', 'docx'];
    
    if (!in_array($fileExt, $allowedExtensions)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file type. Only PDF, DOC, and DOCX allowed.']);
        exit;
    }

    $newFileName = time() . "_" . rand(1000, 9999) . "." . $fileExt;
    $filePath = $uploadDir . $newFileName;

    // Save file
    if (move_uploaded_file($file["tmp_name"], $filePath)) {
        // Directly insert all inputs into the database, including doiLink and editor_id
        $query = "INSERT INTO publications (author_id, editor_id, title, abstract, keywords, co_authors, article_category, article_code, last_revised_article_code, doiLink, file_path) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iisssssssss", $authorId, $editorId, $title, $abstract, $keywords, $coAuthors, $articleCategory, $articleCode, $lastRevisedArticleCode, $doiLink, $filePath);

        // Execute and respond
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Article published successfully!', 'file_url' => $filePath]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to save article details in the database.']);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to upload file.']);
    }

    $conn->close();
}
?>
