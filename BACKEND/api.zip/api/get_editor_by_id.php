
<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Allow specific headers to fix CORS error
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, Cache-Control');

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Disable caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

if (isset($_GET['id'])) {
    $author_id = $_GET['id'];

    if (!filter_var($author_id, FILTER_VALIDATE_INT)) {
        echo json_encode(['success' => false, 'error' => 'Invalid Editor ID.']);
        exit;
    }

    // Select only necessary fields (exclude `password`)
    $query = "SELECT id, full_name, email, affiliation, orcid, phone_code, phone_number, email_verified, created_at 
              FROM editors WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $author_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $author = $result->fetch_assoc();
        echo json_encode(['success' => true, 'author' => $author]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Editor not found.']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Editor ID is required.']);
}

mysqli_close($conn);
?>