<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    // Check if email and password are provided
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Email and password are required.']);
        exit;
    }

    // Prepare SQL statement to retrieve user by email
    $stmt = $conn->prepare("SELECT id, full_name, email, password, email_verified, verification_token FROM editors WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // If user found, check password and handle verification status
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Check if email is verified
            if ($user['email_verified'] == 0) {
                $newToken = bin2hex(random_bytes(16));

                // Update the verification token for the user
                $updateStmt = $conn->prepare("UPDATE editors SET verification_token = ? WHERE id = ?");
                $updateStmt->bind_param("si", $newToken, $user['id']);
                $updateStmt->execute();

                // Generate the verification link
                $verifyUrl = "https://www.fuprecosjournals.org/editorverifyemail/$newToken";
                $subject = "Verify Your Editor Account";
                $message = "Hi " . $user['full_name'] . ",\n\nClick the link below to verify your account:\n$verifyUrl\n\nBest,\nFUPRE JP";
                $headers = "From: no-reply@fuprecosjournals.org\r\n";  // Make sure to use the correct 'from' address

                // Send the email with the verification link
                if (mail($email, $subject, $message, $headers)) {
                    echo json_encode([
                        'success' => false,
                        'error' => 'Email not verified. A new verification link has been sent. Please check your email inbox or spam folder',
                    ]);
                } else {
                    echo json_encode([
                        'success' => false,
                        'error' => 'There was an issue sending the verification email. Please try again.',
                    ]);
                }
            } else {
                // If email is verified, generate and return a login token
                $token = bin2hex(random_bytes(16));  // Create a session or API token

                echo json_encode([
                    'success' => true,
                    'message' => 'Login successful.',
                    'user' => [
                        'id' => $user['id'],
                        'full_name' => $user['full_name'],
                        'email' => $user['email']
                    ],
                    'token' => $token
                ]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid email or password.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'No user found with this email.']);
    }

    // Close the statement and database connection
    $stmt->close();
    mysqli_close($conn);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>
