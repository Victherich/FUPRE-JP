<?php
include 'config.php';

$id = $_GET['id'] ?? 0;

// Fetch publication
$query = "SELECT * FROM publications WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$article = $result->fetch_assoc();

if (!$article) {
    die("Article not found");
}

// Fetch main author name
$authorName = "Unknown Author";
if (!empty($article['author_id'])) {
    $authorQuery = "SELECT full_name FROM authors WHERE id = ?";
    $authorStmt = $conn->prepare($authorQuery);
    $authorStmt->bind_param("i", $article['author_id']);
    $authorStmt->execute();
    $authorResult = $authorStmt->get_result();
    $authorRow = $authorResult->fetch_assoc();
    if ($authorRow) $authorName = $authorRow['full_name'];
}

// Co-authors array
$coAuthors = [];
if (!empty($article['co_authors'])) {
    $coAuthors = array_map('trim', explode(',', $article['co_authors']));
}

// PDF URL
$pdfUrl = "https://www.fuprecosjournals.org/api/" . $article['file_path'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($article['title']); ?></title>

    <!-- GOOGLE SCHOLAR METADATA -->
    <meta name="citation_title" content="<?php echo htmlspecialchars($article['title']); ?>">
    <meta name="citation_author" content="<?php echo htmlspecialchars($authorName); ?>">

    <?php foreach ($coAuthors as $co): ?>
        <meta name="citation_author" content="<?php echo htmlspecialchars($co); ?>">
    <?php endforeach; ?>

    <meta name="citation_publication_date" content="<?php echo date('Y-m-d', strtotime($article['created_at'])); ?>">
    <meta name="citation_journal_title" content="FUPRE Journal of Petroscience">
    <meta name="citation_pdf_url" content="<?php echo $pdfUrl; ?>">
    <meta name="citation_abstract" content="<?php echo htmlspecialchars($article['abstract']); ?>">
    <meta name="citation_keywords" content="<?php echo htmlspecialchars($article['keywords']); ?>">
    <meta name="citation_language" content="en">

    <?php if (!empty($article['doiLink'])): ?>
        <meta name="citation_doi" content="<?php echo htmlspecialchars($article['doiLink']); ?>">
    <?php endif; ?>

    <!-- JSON-LD -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "ScholarlyArticle",
        "headline": "<?php echo htmlspecialchars($article['title']); ?>",
        "author": [
            {"@type": "Person", "name": "<?php echo htmlspecialchars($authorName); ?>"},
            <?php foreach ($coAuthors as $i => $co) {
                echo '{"@type": "Person","name":"' . htmlspecialchars($co) . '"}';
                if ($i < count($coAuthors) - 1) echo ",";
            } ?>
        ],
        "datePublished": "<?php echo date('Y-m-d', strtotime($article['created_at'])); ?>",
        "description": "<?php echo htmlspecialchars($article['abstract']); ?>",
        "keywords": "<?php echo htmlspecialchars($article['keywords']); ?>",
        "url": "https://www.fuprecosjournals.org/api/publicationdetail.php?id=<?php echo $article['id']; ?>",
        "publisher": {
            "@type": "Organization",
            "name": "FUPRE Journal of Petroscience"
        },
        "encoding": {
            "@type": "MediaObject",
            "contentUrl": "<?php echo $pdfUrl; ?>",
            "encodingFormat": "application/pdf"
        }
    }
    </script>

</head>
<body>

<h1><?php echo htmlspecialchars($article['title']); ?></h1>

<p><strong>Main Author:</strong> <?php echo htmlspecialchars($authorName); ?></p>

<?php if ($coAuthors): ?>
<p><strong>Co-Authors:</strong> <?php echo htmlspecialchars(implode(', ', $coAuthors)); ?></p>
<?php endif; ?>

<p><strong>Abstract:</strong> <?php echo nl2br(htmlspecialchars($article['abstract'])); ?></p>
<p><strong>Keywords:</strong> <?php echo htmlspecialchars($article['keywords']); ?></p>

<?php if (!empty($article['doiLink'])): ?>
<p><strong>DOI:</strong> <a href="<?php echo htmlspecialchars($article['doiLink']); ?>" target="_blank"><?php echo htmlspecialchars($article['doiLink']); ?></a></p>
<?php endif; ?>

<br><br>

<!-- BUTTONS -->
<a href="<?php echo $pdfUrl; ?>" 
   target="_blank" 
   style="padding:10px 20px;background:#1e90ff;color:white;text-decoration:none;border-radius:8px;">
   Open PDF in Browser
</a>

<a href="<?php echo $pdfUrl; ?>" 
   download 
   style="padding:10px 20px;background:#ff6347;color:white;text-decoration:none;border-radius:8px;margin-left:10px;">
   Download PDF
</a>

</body>
</html>
