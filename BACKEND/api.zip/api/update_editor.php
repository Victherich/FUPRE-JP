
<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'config.php'; // Database connection

// Get JSON input
$data = json_decode(file_get_contents("php://input"));

if (!$data || !isset($data->id)) {
    echo json_encode(['success' => false, 'error' => 'Editor ID is required.']);
    exit;
}

$author_id = $data->id;
$full_name = $data->full_name ?? null;
$email = $data->email ?? null;
$affiliation = $data->affiliation ?? null;
$orcid = $data->orcid ?? null;
$phone_code = $data->phone_code ?? null;
$phone_number = $data->phone_number ?? null;

// Validate email format
if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Invalid email format.']);
    exit;
}

// Prepare update statement
$query = "UPDATE editors SET full_name=?, email=?, affiliation=?, orcid=?, phone_code=?, phone_number=? WHERE id=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssssssi", $full_name, $email, $affiliation, $orcid, $phone_code, $phone_number, $author_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to update profile.']);
}

$stmt->close();
mysqli_close($conn);
?>