<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

include 'config.php'; // Database connection

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['manuscript_id']) || !filter_var($data['manuscript_id'], FILTER_VALIDATE_INT)) {
    echo json_encode(['success' => false, 'error' => 'Invalid Manuscript ID']);
    exit;
}

$manuscript_id = $data['manuscript_id'];

// Update APC column to "paid"
$query = "UPDATE manuscripts SET APC = 'paid' WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $manuscript_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Payment status updated to paid']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to update payment status']);
}

$stmt->close();
mysqli_close($conn);
?>
