<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

// Get the request data
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['manuscript_id']) || !filter_var($data['manuscript_id'], FILTER_VALIDATE_INT)) {
    echo json_encode(['success' => false, 'error' => 'Invalid Manuscript ID']);
    exit;
}

$manuscript_id = $data['manuscript_id'];

// Fetch the file path before deleting the entry
$query = "SELECT file_path FROM manuscripts WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $manuscript_id);
$stmt->execute();
$result = $stmt->get_result();
$file_path = null;

if ($row = $result->fetch_assoc()) {
    $file_path = $row['file_path'];
}

$stmt->close();

if (!$file_path) {
    echo json_encode(['success' => false, 'error' => 'Manuscript not found']);
    exit;
}

// Delete the file from the server
$file_full_path = __DIR__ . "/uploads/submitted_manuscripts/" . basename($file_path); // Adjust folder path if necessary

if (file_exists($file_full_path)) {
    unlink($file_full_path); // Deletes the file
}

// Delete the manuscript record from the database
$query = "DELETE FROM manuscripts WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $manuscript_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Manuscript and file deleted successfully']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to delete manuscript']);
}

$stmt->close();
mysqli_close($conn);
?>
