<?php
// Allow requests from React frontend
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'config.php'; // Include database connection

// Get the publication ID from the query parameter
$publicationId = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($publicationId)) {
    echo json_encode(['success' => false, 'message' => 'Publication ID is required.']);
    exit;
}

// Prepare SQL query to get the publication by ID
$query = "SELECT * FROM publications WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $publicationId);

$stmt->execute();
$result = $stmt->get_result();

// Check if the publication exists
if ($result->num_rows > 0) {
    $publication = $result->fetch_assoc();
    echo json_encode(['success' => true, 'publication' => $publication]);
} else {
    echo json_encode(['success' => false, 'message' => 'Publication not found.']);
}

$stmt->close();
mysqli_close($conn);
?>
