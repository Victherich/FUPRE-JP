<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the raw POST data
    $data = json_decode(file_get_contents('php://input'), true);

    // Extract the email
    $email = isset($data['email']) ? htmlspecialchars($data['email']) : '';

    // Basic validation
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'A valid email address is required.']);
        exit;
    }

    // Prepare the email (you can also save it to a database instead)
    $to = "fuprecos@fuprecosjournals.org";  // Replace with your email for notifications
    $subject = "New Newsletter Subscription";
    $emailBody = "A new user has subscribed to the newsletter.\n\nEmail: $email";
    $headers = "From: no-reply@fuprecosjournals.org\r\n" .
               "Reply-To: $email\r\n" .
               "X-Mailer: PHP/" . phpversion() .
               "MIME-Version: 1.0\r\n" .
               "Content-Type: text/plain; charset=UTF-8\r\n";

    // Send the email
    if (mail($to, $subject, $emailBody, $headers)) {
        echo json_encode(['success' => true, 'message' => 'Subscription successful!']);
    } else {
        echo json_encode(['success' => false, 'error' => 'There was an error processing your subscription.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>
