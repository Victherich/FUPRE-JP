<?php
// Allow CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'config.php'; // Database connection

// Get the input data
$input = json_decode(file_get_contents("php://input"), true);

$manuscript_id = isset($input['manuscript_id']) ? intval($input['manuscript_id']) : null;
$status = isset($input['status']) ? $input['status'] : null;

// Validate input
if (!$manuscript_id || !in_array($status, ['1', '2', '3', '4', '5', '6', '7'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid manuscript ID or status value.'
    ]);
    exit;
}

// Update the status of the manuscript
$updateQuery = "UPDATE manuscripts SET status = ? WHERE id = ?";
$stmt = $conn->prepare($updateQuery);
$stmt->bind_param("si", $status, $manuscript_id);

if ($stmt->execute()) {
    // Fetch author's email and manuscript title
    $emailQuery = "SELECT authors.email, manuscripts.title
                   FROM manuscripts 
                   JOIN authors ON manuscripts.author_id = authors.id
                   WHERE manuscripts.id = ?";
    $emailStmt = $conn->prepare($emailQuery);
    $emailStmt->bind_param("i", $manuscript_id);
    $emailStmt->execute();
    $emailResult = $emailStmt->get_result();
    $authorData = $emailResult->fetch_assoc();

    if ($authorData) {
        $authorEmail = $authorData['email'];
        $manuscriptTitle = $authorData['title'];

        // Status messages
        $statusMessages = [
            '1' => 'Submitted',
            '2' => 'Assigned for Review',
            '3' => 'Under Review',
            '4' => 'Reviewed',
            '5' => 'Accepted',
            '6' => 'Published',
            '7' => 'Rejected'
        ];
        $statusMessage = isset($statusMessages[$status]) ? $statusMessages[$status] : 'Unknown Status';

        // Send email
        $subject = "Manuscript Status Update: $manuscriptTitle";
        $message = "Dear Author,\n\nYour manuscript titled '$manuscriptTitle' has been updated to the following status: $statusMessage.\n\nThank you for submitting to our journal.\n\nBest regards,\nAJGA Journal Team";
        $headers = "From: no-reply@ajga-journal.org";

        // Use mail() function
        if (mail($authorEmail, $subject, $message, $headers)) {
            echo json_encode([
                'success' => true,
                'message' => 'Status updated and email sent successfully.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Status updated but failed to send email.'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Failed to fetch author email.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to update status.'
    ]);
}

$stmt->close();
mysqli_close($conn);
?>
