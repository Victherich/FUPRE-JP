<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the raw POST data
    $data = json_decode(file_get_contents('php://input'), true);

    // Extract form fields
    $name = isset($data['name']) ? htmlspecialchars($data['name']) : '';
    $email = isset($data['email']) ? htmlspecialchars($data['email']) : '';
    $phone = isset($data['phone']) ? htmlspecialchars($data['phone']) : '';
    $message = isset($data['message']) ? htmlspecialchars($data['message']) : '';

    // Basic validation
    if (empty($name) || empty($email) || empty($phone) || empty($message)) {
        echo json_encode(['success' => false, 'error' => 'All fields are required.']);
        exit;
    }

    // Prepare the email
    $to = "fuprecos@fuprecosjournals.org";  // Corrected the recipient email
    $subject = "New Contact Message from $name";
    $emailBody = "You have received a new message from the contact form.\n\n".
                 "Name: $name\n".
                 "Email: $email\n".
                 "Phone: $phone\n".
                 "Message: $message\n";
    $headers = "From: no-reply@fuprecosjournals.org\r\n" .
               "Reply-To: $email\r\n" .
               "X-Mailer: PHP/" . phpversion() .
               "MIME-Version: 1.0\r\n" .
               "Content-Type: text/plain; charset=UTF-8\r\n";

    // Send the email
    if (mail($to, $subject, $emailBody, $headers)) {
        echo json_encode(['success' => true, 'message' => 'Your message has been sent successfully and we shall get back to you.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'There was an error sending the message.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>
