<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['comment_id']) || !isset($input['text'])) {
        echo json_encode(['success' => false, 'error' => 'Invalid input.']);
        exit();
    }

    $comment_id = intval($input['comment_id']);
    $text = htmlspecialchars($input['text']);

    // Get the manuscript ID from the parent comment
    $sql = "SELECT manuscript_id FROM comments WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $comment_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $manuscript_id = $row['manuscript_id'];

        // Insert the reply
        $insert_sql = "INSERT INTO comments (manuscript_id, parent_id, text) VALUES (?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("iis", $manuscript_id, $comment_id, $text);

        if ($insert_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Reply added successfully.']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to add reply.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Parent comment not found']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}

mysqli_close($conn);
?>
