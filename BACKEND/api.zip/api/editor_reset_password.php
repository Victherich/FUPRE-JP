
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include 'config.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decode JSON payload
    $data = json_decode(file_get_contents('php://input'), true);
    $token = $data['token'] ?? '';
    $newPassword = password_hash($data['password'], PASSWORD_BCRYPT);

    // Validate token
    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'Token is required.']);
        mysqli_close($conn);
        exit();
    }

    // Check if the token is valid
    $stmt = $conn->prepare("SELECT id FROM editors WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $userId = $user['id'];

        // Update password and clear reset token
        $updateStmt = $conn->prepare("UPDATE editors SET password = ?, reset_token = NULL WHERE id = ?");
        $updateStmt->bind_param("si", $newPassword, $userId);

        if ($updateStmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Password reset successfully.']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to reset password.']);
        }

        $updateStmt->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid reset token.']);
    }

    $stmt->close();
    mysqli_close($conn);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>