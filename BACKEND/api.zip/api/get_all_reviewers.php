<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

// Fetch all reviewers
$query = "SELECT * 
          FROM reviewers 
          ORDER BY created_at DESC";

$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$reviewers = [];

while ($row = $result->fetch_assoc()) {
    $reviewers[] = [
        'id' => $row['id'],
        'full_name' => $row['full_name'],
        'email' => $row['email'],
        'phone_code' => $row['phone_code'],
        'phone_number' => $row['phone_number'],
        'affiliation' => $row['affiliation'],
        'orcid' => $row['orcid'],
        'created_at' => $row['created_at']
    ];
}

echo json_encode(['success' => true, 'reviewers' => $reviewers]);

$stmt->close();
mysqli_close($conn);
?>
