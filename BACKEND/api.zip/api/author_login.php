<?php
// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'config.php'; // Include your database connection

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    // Check if email and password are not empty
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'error' => 'Email and password are required.']);
        exit;
    }

    // Prepare statement to check user credentials
    $stmt = $conn->prepare("SELECT id, full_name, email, password, email_verified, verification_token FROM authors WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['password'])) {

            // Check if the email is verified
            if ($user['email_verified'] == 0) {
                // If not verified, generate a new token
                $newToken = bin2hex(random_bytes(16));
                $updateStmt = $conn->prepare("UPDATE authors SET verification_token = ? WHERE id = ?");
                $updateStmt->bind_param("si", $newToken, $user['id']);
                $updateStmt->execute();

                // Send verification email
                $verifyUrl = "https://www.fuprecosjournals.org/authorverifyemail/$newToken";
                $subject = "Verify Your Author Account";
                $message = "Hi " . $user['full_name'] . ",\n\nClick the link below to verify your account:\n$verifyUrl\n\nBest,\nFUPRE JP";
                $headers = "From: no-reply@fuprecosjournals.org\r\n";
                $headers .= "Reply-To: no-reply@fuprecosjournals.org\r\n";
                $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

                mail($email, $subject, $message, $headers);

                echo json_encode([
                    'success' => false,
                    'error' => 'Email not verified. A new verification link has been sent. Please check your email inbox or spam folder.',
                ]);
            } else {
                // If verified, create a token and login
                $token = bin2hex(random_bytes(16));

                echo json_encode([
                    'success' => true,
                    'message' => 'Login successful.',
                    'user' => [
                        'id' => $user['id'],
                        'full_name' => $user['full_name'],
                        'email' => $user['email']
                    ],
                    'token' => $token
                ]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid email or password.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'No user found with this email.']);
    }

    $stmt->close();
    mysqli_close($conn);

} else {
    // If the request is not POST
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>
