<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Include the database configuration
include 'config.php';

// Get the POST data
$data = json_decode(file_get_contents("php://input"), true);

// Validate input
if (empty($data['manuscript_id']) || empty($data['reviewer_id'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields.']);
    exit;
}

$manuscript_id = $data['manuscript_id'];
$reviewer_id = $data['reviewer_id'];

// Check if the manuscript exists
$checkQuery = "SELECT * FROM manuscripts WHERE id = ?";
$checkStmt = $conn->prepare($checkQuery);
$checkStmt->bind_param("i", $manuscript_id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows == 0) {
    echo json_encode(['success' => false, 'error' => 'Manuscript not found.']);
    $checkStmt->close();
    $conn->close();
    exit;
}

// Update the reviewer_id for the manuscript
$updateQuery = "UPDATE manuscripts SET reviewer_id = ? WHERE id = ?";
$updateStmt = $conn->prepare($updateQuery);
$updateStmt->bind_param("ii", $reviewer_id, $manuscript_id);

if ($updateStmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Reviewer assigned successfully.']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to assign reviewer.']);
}

$updateStmt->close();
$conn->close();
?>
