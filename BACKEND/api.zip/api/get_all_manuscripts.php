<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

// Fetch all manuscripts
$query = "SELECT * 
          FROM manuscripts 
          ORDER BY created_at DESC";

$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$manuscripts = [];

while ($row = $result->fetch_assoc()) {
    $manuscripts[] = [
        'id' => $row['id'],
        'title' => $row['title'],
        'article_code' => $row['article_code'],
        'article_category' => $row['article_category'],
        'file_path' => $row['file_path'],
        'submittedDate' => $row['created_at'],
        'status' => $row['status'],
        'lastUpdated' => $row['updated_at'],
        'abstract' => $row['abstract'],
        'APC' => $row['APC'],
        'reviewer_id' => $row['reviewer_id'],
        'submission_type' => $row['submission_type'],
            'original_article_code' => $row['original_article_code'],
    ];
}

echo json_encode(['success' => true, 'manuscripts' => $manuscripts]);

$stmt->close();
mysqli_close($conn);
?>
