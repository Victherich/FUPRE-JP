<?php
// Enable error reporting (for debugging, remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ---------------- CORS & Headers ----------------
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Prevent browser caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Pragma: no-cache');

include 'config.php'; // Database connection

$response = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // ---------------- Retrieve Form Data ----------------
    $conference_id = $_POST['conference_id'] ?? '';
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $school = $_POST['school'] ?? '';
    $abstract = $_FILES['abstract'] ?? null;
    $proof = $_FILES['proof'] ?? null;

    // ---------------- Validate Required Fields ----------------
    if (empty($conference_id) || empty($name) || empty($email) || empty($school) || !$proof) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    // ---------------- Get Conference Name ----------------
    $confQuery = "SELECT title FROM conferences WHERE id = ?";
    $stmtConf = $conn->prepare($confQuery);
    $stmtConf->bind_param("i", $conference_id);
    $stmtConf->execute();
    $stmtConf->bind_result($conference_name);
    if (!$stmtConf->fetch()) {
        $stmtConf->close();
        $conn->close();
        echo json_encode(['success' => false, 'message' => 'Invalid conference ID.']);
        exit;
    }
    $stmtConf->close();

    // ---------------- File Uploads ----------------
    $uploadDir = "uploads/conference/";
    if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

    // Abstract (optional)
    $abstractPath = null;
    if ($abstract && !empty($abstract['name'])) {
        $abstractName = time() . "_abstract_" . rand(1000, 9999) . "." . pathinfo($abstract['name'], PATHINFO_EXTENSION);
        $abstractPath = $uploadDir . $abstractName;
        if (!move_uploaded_file($abstract['tmp_name'], $abstractPath)) {
            echo json_encode(['success' => false, 'message' => 'Failed to upload abstract.']);
            exit;
        }
    }

    // Proof of Payment (required)
    $proofName = time() . "_proof_" . rand(1000, 9999) . "." . pathinfo($proof['name'], PATHINFO_EXTENSION);
    $proofPath = $uploadDir . $proofName;
    if (!move_uploaded_file($proof['tmp_name'], $proofPath)) {
        echo json_encode(['success' => false, 'message' => 'Failed to upload proof of payment.']);
        exit;
    }

    // ---------------- Insert Into Database ----------------
    $query = "INSERT INTO conference_registrations 
        (conference_id, name, email, school, abstract_path, proof_path, payment_status, registration_status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, 'Pending', 'Pending', NOW())";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Database prepare failed.']);
        $conn->close();
        exit;
    }

    $stmt->bind_param("isssss", $conference_id, $name, $email, $school, $abstractPath, $proofPath);

    if ($stmt->execute()) {

        // ---------------- Email Headers ----------------
        $headers  = "From: cosjournals@fupre.edu.ng\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "Content-Transfer-Encoding: 8bit\r\n";

        // ---------------- Email to User ----------------
        $subjectUser = "Conference Registration Received";
        $messageUser = "Dear $name,\n\nYour registration for the conference \"$conference_name\" has been received successfully.\n\n".
                       "You will get another email with your PASSCODE to the conference once your payment is confirmed.\n\nFUPRE JP Conference Team";
        mail($email, $subjectUser, $messageUser, $headers);

        // ---------------- Email to Admin ----------------
        $adminEmail = "cosjournals@fupre.edu.ng";
        $subjectAdmin = "New Conference Registration Submitted";
        $messageAdmin = "Hello Admin,\n\nA new participant registered for \"$conference_name\".\n\n".
                        "Name: $name\nEmail: $email\nSchool: $school\nProof: $proofPath\nAbstract: " . ($abstractPath ?: "None") . "\n\n".
                        "Please log in to your dashboard to review and approve this registration.\n\n".
                        "- Automated Notification System FUPRE JP";
        mail($adminEmail, $subjectAdmin, $headers);

        echo json_encode(['success' => true, 'message' => 'Registration submitted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save registration in the database.']);
    }

    $stmt->close();
    $conn->close();
}
?>
