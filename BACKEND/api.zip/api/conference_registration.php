<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

include 'config.php'; // Database connection

$response = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Retrieve form fields
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $school = $_POST['school'] ?? '';
    $abstract = $_FILES['abstract'] ?? null;
    $proof = $_FILES['proof'] ?? null;

    // Validate required fields
    if(empty($name) || empty($email) || empty($school) || !$proof){
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    // File upload settings
    $uploadDir = "uploads/conference/";
    if(!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

    // Abstract
    $abstractName = time() . "_abstract_" . rand(1000,9999) . "." . pathinfo($abstract['name'], PATHINFO_EXTENSION);
    $abstractPath = $uploadDir . $abstractName;
    move_uploaded_file($abstract['tmp_name'], $abstractPath);

    // Proof of Payment
    $proofName = time() . "_proof_" . rand(1000,9999) . "." . pathinfo($proof['name'], PATHINFO_EXTENSION);
    $proofPath = $uploadDir . $proofName;
    move_uploaded_file($proof['tmp_name'], $proofPath);

    // Insert into database
    $query = "INSERT INTO conference_registrations (name, email, school, abstract_path, proof_path, payment_status, registration_status, created_at) 
              VALUES (?, ?, ?, ?, ?, 'Pending', 'Pending', NOW())";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $name, $email, $school, $abstractPath, $proofPath);

    if($stmt->execute()){
        // Send initial confirmation email
        $subject = "Conference Registration Received";
        $message = "Dear $name,\n\nYour conference registration has been received and your payment is being confirmed. We will notify you once your registration is approved.\n\n- FUPRE Conference Team";
        $headers = "From: cosjournals@fupre.edu.ng";

        mail($email, $subject, $message, $headers);

        echo json_encode(['success' => true, 'message' => 'Registration submitted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save registration in the database.']);
    }

    $stmt->close();
    $conn->close();
}
?>
