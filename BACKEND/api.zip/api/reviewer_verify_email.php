
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $token = $data['token'] ?? '';

    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'Token is required.']);
        exit;
    }

    // Check if token exists
    $stmt = $conn->prepare("SELECT id, email_verified FROM reviewers WHERE verification_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if ($user['email_verified'] == 1) {
            echo json_encode(['success' => false, 'error' => 'This email has already been verified.']);
        } else {
            // Mark email as verified
            $updateStmt = $conn->prepare("UPDATE reviewers SET email_verified = 1, verification_token = NULL WHERE verification_token = ?");
            $updateStmt->bind_param("s", $token);

            if ($updateStmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Your email has been verified successfully.']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Failed to update verification status.']);
            }

            $updateStmt->close();
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid or expired token.']);
    }

    $stmt->close();
    mysqli_close($conn);
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
}
?>