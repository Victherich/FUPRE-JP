<?php
// -------------------- CORS & Headers --------------------
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// Prevent browser caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");

// -------------------- Load DB --------------------
include "config.php";

if (!isset($_GET['conference_id'])) {
    echo json_encode(["success" => false, "message" => "Conference ID missing"]);
    exit;
}

$conference_id = intval($_GET['conference_id']);

$sql = "SELECT 
            id,
            name,
            email,
            school,
            abstract_path,
            proof_path,
            payment_status,
            registration_status,
            created_at,
            passcode
        FROM conference_registrations
        WHERE conference_id = ?
        ORDER BY id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $conference_id);
$stmt->execute();

$result = $stmt->get_result();
$output = [];

while ($row = $result->fetch_assoc()) {
    $output[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $output
]);

$stmt->close();
$conn->close();
?>
